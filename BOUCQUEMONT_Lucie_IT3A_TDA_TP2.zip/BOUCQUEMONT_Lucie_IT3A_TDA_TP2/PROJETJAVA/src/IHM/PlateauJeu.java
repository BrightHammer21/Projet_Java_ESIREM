package IHM;

import Entités.Joueur;
import IHM.MenuJeu.ZonesJeu.*;
import Métier.Case;
import Métier.Puissance4;
import javafx.scene.Parent;
import javafx.stage.Stage;

public class PlateauJeu extends Parent {

    //ATTRIBUTS
    private Stage primaryStage;
    private Stage fenetre;

    private ZoneJoueur1 zoneJoueur1;
    private ZoneJoueur2 zoneJoueur2;
    private ZoneJeu zoneJeu;
    private ZoneInfoJoueur info;
    private ZoneTourSuivant tourSuivant;
    private ZonePoserJeton poser;

    private Puissance4 p;


    public PlateauJeu(Stage prmaryStage, Stage nouvelle_fenetre, Joueur joueur1, Joueur joueur2, Case[][] plateauCase, Puissance4 p)
    {
        this.primaryStage=prmaryStage;
        this.fenetre=nouvelle_fenetre;
        this.p=p;

        info = new ZoneInfoJoueur(p);
        this.getChildren().add(info);

        zoneJeu = new ZoneJeu(primaryStage,nouvelle_fenetre,this,joueur1, joueur2, plateauCase, p);
        this.getChildren().add(zoneJeu);

        zoneJoueur1 = new ZoneJoueur1(this, joueur1, p,zoneJeu);
        this.getChildren().add(zoneJoueur1);

        zoneJoueur2 = new ZoneJoueur2(this, joueur2,p,zoneJeu);
        this.getChildren().add(zoneJoueur2);

        tourSuivant=new ZoneTourSuivant(info, p,zoneJoueur1,zoneJoueur2,zoneJeu,nouvelle_fenetre);
        this.getChildren().add(tourSuivant);

        poser=new ZonePoserJeton(p,zoneJoueur1,zoneJoueur2,tourSuivant,zoneJeu,nouvelle_fenetre);
        this.getChildren().add(poser);



        ////////BLOQUAGE DE REDUCTION DE LA FENETRE
        nouvelle_fenetre.setMinWidth(1280);
        nouvelle_fenetre.setMaxWidth(1285);
        nouvelle_fenetre.setMinHeight(850);
        nouvelle_fenetre.setMaxHeight(855);
    }


}
