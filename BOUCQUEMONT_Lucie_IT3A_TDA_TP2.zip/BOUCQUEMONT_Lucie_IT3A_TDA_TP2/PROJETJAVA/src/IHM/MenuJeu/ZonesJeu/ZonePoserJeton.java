package IHM.MenuJeu.ZonesJeu;

import IHM.MenuJeu.FenetrePartieFinie.*;
import Métier.Case;
import Métier.Puissance4;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.Border;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;
import org.omg.CORBA.portable.IDLEntity;

public class ZonePoserJeton extends Parent {

    private Pane zonePose;
    private Puissance4 p;
    private ZoneJoueur1 j1;
    private ZoneJoueur2 j2;
    private ZoneTourSuivant tour;
    private ZoneJeu jeu;
    private boolean partieFinieMatchNul;
    private boolean partieFinie;
    private Stage cett_fenetre;


    public ZonePoserJeton(Puissance4 p, ZoneJoueur1 j1, ZoneJoueur2 j2, ZoneTourSuivant tour, ZoneJeu jeu,Stage cette_fenetre)
    {
        this.p=p;
        this.j1=j1;
        this.j2=j2;
        this.tour=tour;
        this.jeu=jeu;
        this.cett_fenetre=cette_fenetre;


        partieFinieMatchNul=p.partieMatchNul();
        partieFinie=p.partieFinie();

        genererBoutonsPose();
    }

    public void genererBoutonsPose()
    {
            zonePose = new Pane();

            ////////////////////////////////////////////////////////////BOUTONS
            Button b_col0 = new Button("↓");
            b_col0.setLayoutY(70);
            b_col0.setLayoutX(250);
            b_col0.setTextFill(Color.WHITE);
            b_col0.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 22));
            b_col0.setPrefSize(40, 40);
            b_col0.setShape(new Circle(1.5));


            Button b_col1 = new Button("↓");
            b_col1.setLayoutY(70);
            b_col1.setLayoutX(370);
            b_col1.setTextFill(Color.WHITE);
            b_col1.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 22));
            b_col1.setPrefSize(40, 40);
            b_col1.setShape(new Circle(1.5));


            Button b_col2 = new Button("↓");
            b_col2.setLayoutY(70);
            b_col2.setLayoutX(490);
            b_col2.setTextFill(Color.WHITE);
            b_col2.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 22));
            b_col2.setPrefSize(40, 40);
            b_col2.setShape(new Circle(1.5));

            Button b_col3 = new Button("↓");
            b_col3.setLayoutY(70);
            b_col3.setLayoutX(610);
            b_col3.setTextFill(Color.WHITE);
            b_col3.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 22));
            b_col3.setPrefSize(40, 40);
            b_col3.setShape(new Circle(1.5));

            Button b_col4 = new Button("↓");
            b_col4.setLayoutY(70);
            b_col4.setLayoutX(730);
            b_col4.setTextFill(Color.WHITE);
            b_col4.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 22));
            b_col4.setPrefSize(40, 40);
            b_col4.setShape(new Circle(1.5));

            Button b_col5 = new Button("↓");
            b_col5.setLayoutY(70);
            b_col5.setLayoutX(850);
            b_col5.setTextFill(Color.WHITE);
            b_col5.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 22));
            b_col5.setShape(new Circle(1.5));

            Button b_col6 = new Button("↓");
            b_col6.setLayoutY(70);
            b_col6.setLayoutX(970);
            b_col6.setTextFill(Color.WHITE);
            b_col6.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 22));
            b_col6.setPrefSize(40, 40);
            b_col6.setShape(new Circle(1.5));

            /////////////////////////////////////////////////////////////////////////////////MENU
            Button b_Menu=new Button("MENU");
            b_Menu.setLayoutX(1115);
            b_Menu.setLayoutY(70);
            b_Menu.setTextFill(Color.WHITE);
            b_Menu.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 18));
            b_Menu.setPrefSize(120,20);

            b_Menu.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null)));
            b_Menu.setOnMouseEntered(e->b_Menu.setBackground(new Background(new BackgroundFill(Color.rgb(33,232,46), null, null))));
            b_Menu.setOnMouseExited(e->b_Menu.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null))));


            b_Menu.setOnAction(new EventHandler<ActionEvent>(){
                @Override
                public void handle(ActionEvent event) {

                    Stage nouveau_menu = new Stage();
                    menuJeu menu_fenetre = new menuJeu(cett_fenetre,nouveau_menu,p);
                    Scene nouvelle_scene = new Scene(menu_fenetre, 420,460);
                    nouveau_menu.setScene(nouvelle_scene);

                    nouveau_menu.show();
                }
            });

            /////////////////////////////////////////////////////////MET AU VERT LES BOUTONS TANT QUE LE JOUEUR N'AS PAS POSE
            if (p.getJoueurCourant().isaPoser() == false) {
                b_col0.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null)));
                b_col0.setOnMouseEntered(e -> b_col0.setBackground(new Background(new BackgroundFill(Color.rgb(33, 232, 46), null, null))));
                b_col0.setOnMouseExited(e -> b_col0.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null))));

                b_col1.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null)));
                b_col1.setOnMouseEntered(e -> b_col1.setBackground(new Background(new BackgroundFill(Color.rgb(33, 232, 46), null, null))));
                b_col1.setOnMouseExited(e -> b_col1.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null))));

                b_col2.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null)));
                b_col2.setOnMouseEntered(e -> b_col2.setBackground(new Background(new BackgroundFill(Color.rgb(33, 232, 46), null, null))));
                b_col2.setOnMouseExited(e -> b_col2.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null))));

                b_col3.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null)));
                b_col3.setOnMouseEntered(e -> b_col3.setBackground(new Background(new BackgroundFill(Color.rgb(33, 232, 46), null, null))));
                b_col3.setOnMouseExited(e -> b_col3.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null))));

                b_col4.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null)));
                b_col4.setOnMouseEntered(e -> b_col4.setBackground(new Background(new BackgroundFill(Color.rgb(33, 232, 46), null, null))));
                b_col4.setOnMouseExited(e -> b_col4.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null))));

                b_col5.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null)));
                b_col5.setOnMouseEntered(e -> b_col5.setBackground(new Background(new BackgroundFill(Color.rgb(33, 232, 46), null, null))));
                b_col5.setOnMouseExited(e -> b_col5.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null))));
                b_col5.setPrefSize(40, 40);

                b_col6.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null)));
                b_col6.setOnMouseEntered(e -> b_col6.setBackground(new Background(new BackgroundFill(Color.rgb(33, 232, 46), null, null))));
                b_col6.setOnMouseExited(e -> b_col6.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null))));
            }


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////ACTIONS

            //BOUTON COO Y 0
            b_col0.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    if (((p.getJoueurCourant() == p.getJoueur1()) && (p.getJoueur1().isaPoser() == false)) || ((p.getJoueurCourant() == p.getJoueur2()) && (p.getJoueur2().isaPoser() == false))) {

                        if(p.colonnePleine(0)==false)
                        {
                            p.getJoueurCourant().setaPoser(p.poserJeton(p.getJoueurCourant(), 0)); //met à true le fait qu'il a posé

                            boutonsGrisJoueurPose(b_col0, b_col1, b_col2, b_col3, b_col4, b_col5, b_col6);
                        }


                    }
                }
            });

            //BOUTON COO Y 1
            b_col1.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    if (((p.getJoueurCourant() == p.getJoueur1()) && (p.getJoueur1().isaPoser() == false)) || ((p.getJoueurCourant() == p.getJoueur2()) && (p.getJoueur2().isaPoser() == false))) {

                        if(p.colonnePleine(1)==false) {
                            p.getJoueurCourant().setaPoser(p.poserJeton(p.getJoueurCourant(), 1));
                            boutonsGrisJoueurPose(b_col0, b_col1, b_col2, b_col3, b_col4, b_col5, b_col6);
                        }
                    }
                }
            });

            //BOUTON COO Y 2
            b_col2.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    if (((p.getJoueurCourant() == p.getJoueur1()) && (p.getJoueur1().isaPoser() == false)) || ((p.getJoueurCourant() == p.getJoueur2()) && (p.getJoueur2().isaPoser() == false))) {

                        if(p.colonnePleine(2)==false) {
                            p.getJoueurCourant().setaPoser(p.poserJeton(p.getJoueurCourant(), 2));
                            boutonsGrisJoueurPose(b_col0, b_col1, b_col2, b_col3, b_col4, b_col5, b_col6);
                        }


                    }
                }
            });

            //BOUTON COO Y 3
            b_col3.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    if (((p.getJoueurCourant() == p.getJoueur1()) && (p.getJoueur1().isaPoser() == false)) || ((p.getJoueurCourant() == p.getJoueur2()) && (p.getJoueur2().isaPoser() == false))) {

                        if(p.colonnePleine(3)==false) {
                            p.getJoueurCourant().setaPoser(p.poserJeton(p.getJoueurCourant(), 3));
                            boutonsGrisJoueurPose(b_col0, b_col1, b_col2, b_col3, b_col4, b_col5, b_col6);
                        }

                    }
                }
            });

            //BOUTON COO Y 4
            b_col4.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    if (((p.getJoueurCourant() == p.getJoueur1()) && (p.getJoueur1().isaPoser() == false)) || ((p.getJoueurCourant() == p.getJoueur2()) && (p.getJoueur2().isaPoser() == false))) {

                        if(p.colonnePleine(4)==false) {
                            p.getJoueurCourant().setaPoser(p.poserJeton(p.getJoueurCourant(), 4));
                            boutonsGrisJoueurPose(b_col0, b_col1, b_col2, b_col3, b_col4, b_col5, b_col6);
                        }


                    }
                }
            });

            //BOUTON COO Y 5
            b_col5.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    if (((p.getJoueurCourant() == p.getJoueur1()) && (p.getJoueur1().isaPoser() == false)) || ((p.getJoueurCourant() == p.getJoueur2()) && (p.getJoueur2().isaPoser() == false))) {

                        if(p.colonnePleine(5)==false) {
                            p.getJoueurCourant().setaPoser(p.poserJeton(p.getJoueurCourant(), 5));
                            boutonsGrisJoueurPose(b_col0, b_col1, b_col2, b_col3, b_col4, b_col5, b_col6);
                        }


                    }
                }
            });

            //BOUTON COO Y 6
            b_col6.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    if (((p.getJoueurCourant() == p.getJoueur1()) && (p.getJoueur1().isaPoser() == false)) || ((p.getJoueurCourant() == p.getJoueur2()) && (p.getJoueur2().isaPoser() == false))) {

                        if(p.colonnePleine(6)==false) {
                            p.getJoueurCourant().setaPoser(p.poserJeton(p.getJoueurCourant(), 6));
                            boutonsGrisJoueurPose(b_col0, b_col1, b_col2, b_col3, b_col4, b_col5, b_col6);
                        }


                    }
                }
            });


            ///////////////////////////////////////////////////////////GRISE LE BOUTON DE LA COLONNE CORRESPONDANTE SI PLEINE
            Case listeCase[][] = p.getListeCase();

            if (listeCase[0][0].isEstOccupe()) {
                b_col0.setBackground(new Background(new BackgroundFill(Color.GREY, null, null)));
                b_col0.setOnMouseEntered(e -> b_col0.setBackground(new Background(new BackgroundFill(Color.GREY, null, null))));
                b_col0.setOnMouseExited(e -> b_col0.setBackground(new Background(new BackgroundFill(Color.GREY, null, null))));
            }
            if (listeCase[0][1].isEstOccupe()) {
                b_col1.setBackground(new Background(new BackgroundFill(Color.GREY, null, null)));
                b_col1.setOnMouseEntered(e -> b_col1.setBackground(new Background(new BackgroundFill(Color.GREY, null, null))));
                b_col1.setOnMouseExited(e -> b_col1.setBackground(new Background(new BackgroundFill(Color.GREY, null, null))));

            }
            if (listeCase[0][2].isEstOccupe()) {
                b_col2.setBackground(new Background(new BackgroundFill(Color.GREY, null, null)));
                b_col2.setOnMouseEntered(e -> b_col2.setBackground(new Background(new BackgroundFill(Color.GREY, null, null))));
                b_col2.setOnMouseExited(e -> b_col2.setBackground(new Background(new BackgroundFill(Color.GREY, null, null))));

            }
            if (listeCase[0][3].isEstOccupe()) {
                b_col3.setBackground(new Background(new BackgroundFill(Color.GREY, null, null)));
                b_col3.setOnMouseEntered(e -> b_col3.setBackground(new Background(new BackgroundFill(Color.GREY, null, null))));
                b_col3.setOnMouseExited(e -> b_col3.setBackground(new Background(new BackgroundFill(Color.GREY, null, null))));

            }
            if (listeCase[0][4].isEstOccupe()) {
                b_col4.setBackground(new Background(new BackgroundFill(Color.GREY, null, null)));
                b_col4.setOnMouseEntered(e -> b_col4.setBackground(new Background(new BackgroundFill(Color.GREY, null, null))));
                b_col4.setOnMouseExited(e -> b_col4.setBackground(new Background(new BackgroundFill(Color.GREY, null, null))));

            }
            if (listeCase[0][5].isEstOccupe()) {
                b_col5.setBackground(new Background(new BackgroundFill(Color.GREY, null, null)));
                b_col5.setOnMouseEntered(e -> b_col5.setBackground(new Background(new BackgroundFill(Color.GREY, null, null))));
                b_col5.setOnMouseExited(e -> b_col5.setBackground(new Background(new BackgroundFill(Color.GREY, null, null))));

            }
            if (listeCase[0][6].isEstOccupe()) {
                b_col6.setBackground(new Background(new BackgroundFill(Color.GREY, null, null)));
                b_col6.setOnMouseEntered(e -> b_col6.setBackground(new Background(new BackgroundFill(Color.GREY, null, null))));
                b_col6.setOnMouseExited(e -> b_col6.setBackground(new Background(new BackgroundFill(Color.GREY, null, null))));

            }


            /////////////////////////////////////////

            zonePose.getChildren().add(b_col0);
            zonePose.getChildren().add(b_col1);
            zonePose.getChildren().add(b_col2);
            zonePose.getChildren().add(b_col3);
            zonePose.getChildren().add(b_col4);
            zonePose.getChildren().add(b_col5);
            zonePose.getChildren().add(b_col6);
            zonePose.getChildren().add(b_Menu);


        //AJOUT A LA SCENE
        this.getChildren().add(zonePose);
    }

    public void detruireBoutonsPose()
    {
        this.getChildren().removeAll(zonePose);
    }

    public void boutonsGrisJoueurPose(Button bt0, Button bt1,Button bt2,Button bt3,Button bt4,Button bt5,Button bt6)
    {
        bt0.setBackground(new Background(new BackgroundFill(Color.GREY, null, null)));
        bt1.setBackground(new Background(new BackgroundFill(Color.GREY, null, null)));
        bt2.setBackground(new Background(new BackgroundFill(Color.GREY, null, null)));
        bt3.setBackground(new Background(new BackgroundFill(Color.GREY, null, null)));
        bt4.setBackground(new Background(new BackgroundFill(Color.GREY, null, null)));
        bt5.setBackground(new Background(new BackgroundFill(Color.GREY, null, null)));
        bt6.setBackground(new Background(new BackgroundFill(Color.GREY, null, null)));


        bt0.setOnMouseEntered(e->bt0.setBackground(new Background(new BackgroundFill(Color.GREY, null, null))));
        bt0.setOnMouseExited(e->bt0.setBackground(new Background(new BackgroundFill(Color.GREY, null, null))));

        bt1.setOnMouseEntered(e->bt0.setBackground(new Background(new BackgroundFill(Color.GREY, null, null))));
        bt1.setOnMouseExited(e->bt0.setBackground(new Background(new BackgroundFill(Color.GREY, null, null))));

        bt2.setOnMouseEntered(e->bt0.setBackground(new Background(new BackgroundFill(Color.GREY, null, null))));
        bt2.setOnMouseExited(e->bt0.setBackground(new Background(new BackgroundFill(Color.GREY, null, null))));

        bt3.setOnMouseEntered(e->bt0.setBackground(new Background(new BackgroundFill(Color.GREY, null, null))));
        bt3.setOnMouseExited(e->bt0.setBackground(new Background(new BackgroundFill(Color.GREY, null, null))));

        bt4.setOnMouseEntered(e->bt0.setBackground(new Background(new BackgroundFill(Color.GREY, null, null))));
        bt4.setOnMouseExited(e->bt0.setBackground(new Background(new BackgroundFill(Color.GREY, null, null))));

        bt5.setOnMouseEntered(e->bt0.setBackground(new Background(new BackgroundFill(Color.GREY, null, null))));
        bt5.setOnMouseExited(e->bt0.setBackground(new Background(new BackgroundFill(Color.GREY, null, null))));

        bt6.setOnMouseEntered(e->bt0.setBackground(new Background(new BackgroundFill(Color.GREY, null, null))));
        bt6.setOnMouseExited(e->bt0.setBackground(new Background(new BackgroundFill(Color.GREY, null, null))));

        //MISE A JOUR DU PLATEAU
        j1.supprimerJoueur1();
        j2.supprimerJoueur2();
        tour.detruireTourSuivant();
        jeu.detruireCase();
        jeu.genererCase();
        j1.générerPion();
        j2.générerPion();
        tour.tourSuivant(this);

        partieFinieMatchNul=p.partieMatchNul();
        partieFinie=p.partieFinie();


        ///////////////////////////////////////////////////////////////////////////////SI PARTIE FINIE
        if(partieFinieMatchNul==true)
        {
            if(p.getJoueur2().getType()=="IA")
            {
                Stage nouvelle_fenetre = new Stage();
                fenetreMatchNulIA matchNul_fenetre = new fenetreMatchNulIA(cett_fenetre,nouvelle_fenetre,p);
                Scene nouvelle_scene = new Scene(matchNul_fenetre,630,380);
                nouvelle_fenetre.setScene(nouvelle_scene);
                nouvelle_fenetre.show();
            }
            else
            {
                Stage nouvelle_fenetre = new Stage();
                fenetreMatchNul matchNul_fenetre = new fenetreMatchNul(cett_fenetre,nouvelle_fenetre,p);
                Scene nouvelle_scene = new Scene(matchNul_fenetre,630,380);
                nouvelle_fenetre.setScene(nouvelle_scene);
                nouvelle_fenetre.show();

            }
        }
        else if(partieFinie==true)
        {
            if(p.getJoueur2().getType()=="IA")
            {
                Stage nouvelle_fenetre = new Stage();
                fenetrePartieFinieIA fini_fenetre = new fenetrePartieFinieIA(cett_fenetre,nouvelle_fenetre,p);
                Scene nouvelle_scene = new Scene(fini_fenetre,630,380);

                nouvelle_fenetre.setScene(nouvelle_scene);
                nouvelle_fenetre.show();
            }
            else
            {
                Stage nouvelle_fenetre = new Stage();
                fenetrePartieFinie fini_fenetre = new fenetrePartieFinie(cett_fenetre,nouvelle_fenetre,p);
                Scene nouvelle_scene = new Scene(fini_fenetre,630,380);

                nouvelle_fenetre.setScene(nouvelle_scene);
                nouvelle_fenetre.show();
            }
        }
    }
}
