package Entités;

import javafx.scene.paint.Color;

import java.util.ArrayList;

public abstract class Joueur {

    //ATTRIBUTS
    private String nom;
    private Color couleurJeton; //determinera la couleur du jeton
    private ArrayList<Jeton> listeJeton;
    private ArrayList<Jeton> listeJetonJoue;
    private int size=21;
    private boolean aPoser;
    //Constructeur
    public Joueur(String nom, Color couleurJeton)
    {
        this.nom=nom;
        this.couleurJeton=couleurJeton;
        listeJeton=new ArrayList<>();
        listeJetonJoue=new ArrayList<>();
        aPoser=false;

        Jeton jeton = new Jeton(couleurJeton);
        for(int i=0;i<21;i++)
        {
            listeJeton.add(jeton);
        }
    }

    //GETTER ET SETTER
    public String getNom()
    {
        return nom;
    }

    public void setString(String nom)
    {
        this.nom=nom;
    }

    public Color getCouleurJeton()
    {
        return couleurJeton;
    }

    public void setCouleurJeton(Color couleur)
    {
        this.couleurJeton=couleur;
    }

    public ArrayList<Jeton> getListeJeton() {
        return listeJeton;
    }

    public void setListeJeton() {
        Jeton jeton = new Jeton(couleurJeton);
        ArrayList<Jeton> j = new ArrayList<>();
        size--;
        for(int i=0;i<size;i++)
        {
            j.add(jeton);
        }
        this.listeJeton=j;
    }

    public ArrayList<Jeton> getListeJetonJoue() {
        return listeJetonJoue;
    }

    public void setListeJetonJoue(Jeton JetonJoue) {
        this.listeJetonJoue.add(JetonJoue);
    }

    public void setaPoser(boolean aPoser) {
        this.aPoser = aPoser;
    }


    public boolean isaPoser() {
        return aPoser;
    }

    //METHODE ABSTRAITE POUR R2CUPERER LE TYPE DE JOUEUR (Humain ou IA)
    public abstract String getType();
}

