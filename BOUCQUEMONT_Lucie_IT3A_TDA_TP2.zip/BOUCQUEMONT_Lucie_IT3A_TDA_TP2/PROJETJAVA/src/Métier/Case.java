package Métier;

import Entités.Coordonnées;
import Entités.Joueur;

public class Case {
    //Attributs
    private Coordonnées coo;
    private boolean estOccupe;
    private Joueur j;

    //CONSTRUCTEUR
    public Case (Coordonnées coo)
    {
        this.coo=coo;
        this.estOccupe=false;
        this.j=null;
    }

    //GETTER ET SETTER
    public Coordonnées getCoo() {
        return coo;
    }

    public boolean isEstOccupe() {
        return estOccupe;
    }

    public void setEstOccupe(boolean estOccupe) {
        this.estOccupe = estOccupe;
    }

    public Joueur getJ() {
        return j;
    }

    public void setJ(Joueur j) {
        this.j = j;
    }


}
