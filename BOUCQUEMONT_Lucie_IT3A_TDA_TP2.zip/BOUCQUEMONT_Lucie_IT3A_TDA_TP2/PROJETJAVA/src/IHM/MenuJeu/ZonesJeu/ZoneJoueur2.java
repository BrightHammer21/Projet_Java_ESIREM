package IHM.MenuJeu.ZonesJeu;

import Entités.Joueur;
import IHM.PlateauJeu;
import Métier.Puissance4;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class ZoneJoueur2 extends Parent {

    private Pane infoJoueur2;
    private PlateauJeu jeu;
    private Joueur joueur2;
    private ZoneJeu zonejeu;

    private int compteur=0;
    private int posY=250;
    private int posX=1125;


    //CONSTRUCTEUR
    public ZoneJoueur2(PlateauJeu jeu, Joueur joueur2,Puissance4 p, ZoneJeu zonejeu) {

        this.jeu=jeu;
        this.joueur2=joueur2;
        this.zonejeu=zonejeu;

        générerPion();

    }

    public void générerPion()
    {
        //CREATION DU PANE
        infoJoueur2 = new Pane();

        //RECTANGLE
        Rectangle rectangle = new Rectangle();
        rectangle.setHeight(410);
        rectangle.setWidth(150);
        rectangle.setX(1100);
        rectangle.setY(170);
        rectangle.setFill(Color.TRANSPARENT);
        rectangle.setStroke(Color.BLACK);
        infoJoueur2.getChildren().add(rectangle);

        //LABEL JOUEUR
        Button l_joueur2 = new Button(joueur2.getNom());
        l_joueur2.setLayoutX(1100);
        l_joueur2.setLayoutY(170);
        l_joueur2.setPrefSize(150,50);
        l_joueur2.setTextFill(Color.WHITE);
        l_joueur2.setBackground(new Background(new BackgroundFill(joueur2.getCouleurJeton(),null,null)));
        l_joueur2.setFont(Font.font("Verdana", FontWeight.BOLD, 14));
        infoJoueur2.getChildren().add(l_joueur2);

        //GENERATION DES JETONS
        for(int i=0; i<joueur2.getListeJeton().size();i++)
        {
            Circle c = new Circle();
            c.setFill(joueur2.getCouleurJeton());
            c.setRadius(20);
            c.setStroke(Color.BLACK);
            c.setStrokeWidth(1);

            if(compteur==3)
            {
                compteur = 0;
                posY+=50;
                posX=1125;
            }
            c.setLayoutX(posX);
            c.setLayoutY(posY);

            posX+=50;
            compteur++;

            infoJoueur2.getChildren().add(c);

        }

        posY=250;
        posX=1125;
        compteur=0;

        //AJOUT DU PANE A LA SCENE
        this.getChildren().add(infoJoueur2);

    }

    public void supprimerJoueur2()
    {
        this.getChildren().removeAll(infoJoueur2);
    }
}
