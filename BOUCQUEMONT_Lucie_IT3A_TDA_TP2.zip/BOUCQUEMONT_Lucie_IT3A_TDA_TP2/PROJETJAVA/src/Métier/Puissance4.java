package Métier;

import Entités.Coordonnées;
import Entités.Humain;
import Entités.Jeton;
import Entités.Joueur;
import IHM.PlateauJeu;
import javafx.scene.paint.Color;

import java.util.ArrayList;
import java.util.Random;

public class Puissance4 {

     //ATTRIBUTS
    private Case[][] listeCase;
    private Joueur joueurCourant;
    private Joueur joueur1;
    private Joueur joueur2;
    private Joueur joueurGagnant;
    private boolean terminee;
    private Random rand = new Random();

    public Puissance4(Joueur joueur1, Joueur joueur2, Case[][] plateauCase)
    {
        terminee=false;

        this.joueur1 = joueur1;
        this.joueur2 = joueur2;
        this.listeCase=plateauCase;

        joueurCourant=joueur1;
    }


    //GETTER ET SETTER
    public Joueur getJoueurCourant() {
        return joueurCourant;
    }

    public void setJoueurCourant(Joueur joueurCourant) {
        this.joueurCourant = joueurCourant;
    }

    public Joueur getJoueur1() {
        return joueur1;
    }

    public void setJoueur1(Joueur joueur1) {
        this.joueur1 = joueur1;
    }

    public Joueur getJoueur2() {
        return joueur2;
    }

    public Case[][] getListeCase() {
        return listeCase;
    }

    public void setListeCase(Case[][] listeCase) {
        this.listeCase = listeCase;
    }


    public Joueur getJoueurGagnant() {
        return joueurGagnant;
    }

    public void setJoueurGagnant(Joueur joueurGagnant) {
        this.joueurGagnant = joueurGagnant;
    }


    //METHODES
    public boolean poserJeton(Joueur JoueurCourant, int y)
    {
        boolean res=true;

        if(joueurCourant.getListeJeton().size()==0)
        {
            res=false;
            terminee=true;
        }
        else{
            if(listeCase[5][y].isEstOccupe()==false)
            {
                listeCase[5][y].setEstOccupe(true);
                listeCase[5][y].setJ(JoueurCourant);

                joueurCourant.setListeJetonJoue(new Jeton(joueurCourant.getCouleurJeton()));
                joueurCourant.setListeJeton();
                cooPoseJoueur(5,y);
            }
            else if(listeCase[4][y].isEstOccupe()==false)
            {
                listeCase[4][y].setEstOccupe(true);
                listeCase[4][y].setJ(JoueurCourant);

                joueurCourant.setListeJetonJoue(new Jeton(joueurCourant.getCouleurJeton()));
                joueurCourant.setListeJeton();
                cooPoseJoueur(5,y);
            }
            else if(listeCase[3][y].isEstOccupe()==false)
            {
                listeCase[3][y].setEstOccupe(true);
                listeCase[3][y].setJ(JoueurCourant);

                joueurCourant.setListeJetonJoue(new Jeton(joueurCourant.getCouleurJeton()));
                joueurCourant.setListeJeton();
                cooPoseJoueur(5,y);
            }
            else if(listeCase[2][y].isEstOccupe()==false)
            {
                listeCase[2][y].setEstOccupe(true);
                listeCase[2][y].setJ(JoueurCourant);

                joueurCourant.setListeJetonJoue(new Jeton(joueurCourant.getCouleurJeton()));
                joueurCourant.setListeJeton();
                cooPoseJoueur(5,y);
            }
            else if(listeCase[1][y].isEstOccupe()==false)
            {
                listeCase[1][y].setEstOccupe(true);
                listeCase[1][y].setJ(JoueurCourant);

                joueurCourant.setListeJetonJoue(new Jeton(joueurCourant.getCouleurJeton()));
                joueurCourant.setListeJeton();
                cooPoseJoueur(5,y);
            }
            else if(listeCase[0][y].isEstOccupe()==false)
            {
                listeCase[0][y].setEstOccupe(true);
                listeCase[0][y].setJ(JoueurCourant);

                joueurCourant.setListeJetonJoue(new Jeton(joueurCourant.getCouleurJeton()));
                joueurCourant.setListeJeton();
                cooPoseJoueur(5,y);
            }
            else
            {

                if(joueurCourant.getType()=="IA")
                {
                    iaRandom();
                }
                else
                {
                    res=false;
                    System.out.println("La colonne est pleine !! choisissez en une autre !");
                }
            }
        }

        return res;
    }

    /////////////////////////////////////////////////////////////////////////////////////////////// POSE IA

    public boolean iaPose(Joueur JoueurCourant)
    {
        boolean res=false;
        boolean aPose=false;

        if(joueurCourant.getListeJeton().size()==0)
        {
            res=false;
            terminee=true;
        }
        else
        {
            aPose=joueur1AligneJetonHorizontalementGDH(JoueurCourant);

            if(aPose==false)
            {

                aPose=joueurAligneJetonDG(JoueurCourant);
                if(aPose==false)
                {
                    aPose=joueur1AligneJetonVerticalement(JoueurCourant);


                    if(aPose==false)
                    {
                        aPose = joueur1AligneJetonHorizontalement(JoueurCourant);
                        if(aPose==false)
                        {
                            iaRandom();
                        }
                    }

                }
            }
        }

        return res;
    }

    /////////////////////////////////////////////
    public boolean colonnePleine(int y)
    {
        boolean res = false;

        if(listeCase[0][y].isEstOccupe())
        {
            res =true;
        }
        return res;
    }

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public boolean joueurAligneJetonDG(Joueur JoueurCourant)
    {
        boolean joueurPose=JoueurCourant.isaPoser();

        for(int ligne=0;ligne<6;ligne++)
        {
            for (int col = 0; col < 7; col++)
            {
                if(col==0 && ligne<4)
                {
                    if(listeCase[ligne][col].isEstOccupe()&&listeCase[ligne+1][col+1].isEstOccupe()) {
                        if ((listeCase[ligne][col].getJ() == joueur1) && (listeCase[ligne + 1][col+1].getJ() == joueur1)) {

                            if(ligne+2==5)
                            {
                                if ((listeCase[ligne + 2][col+2].isEstOccupe() == false))
                                {
                                    casePrise(ligne+2,col+2);
                                    joueurPose = true;
                                }

                            }
                            else
                            {
                                if ((listeCase[ligne + 2][col+2].isEstOccupe() == false) && (joueurPose == false)&&(listeCase[ligne +1 ][col+2].isEstOccupe()))
                                {
                                    casePrise(ligne+2,col+2);
                                    joueurPose = true;
                                }
                            }
                        }
                    }
                }
                else if(col==6 && ligne>1)
                {
                    if (listeCase[ligne][col].isEstOccupe() && listeCase[ligne - 1][col - 1].isEstOccupe())
                    {
                        if ((listeCase[ligne][col].getJ() == joueur1) && (listeCase[ligne - 1][col - 1].getJ() == joueur1))
                        {
                            if ((listeCase[ligne -2][col-2].isEstOccupe() == false) && (joueurPose == false)&&(listeCase[ligne -1 ][col-2].isEstOccupe()))
                            {
                                casePrise(ligne-2,col-2);
                                joueurPose = true;
                            }
                        }
                    }
                }
                else if(col>1 && col<5 && ligne>0)
                {
                    if (listeCase[ligne][col].isEstOccupe() && listeCase[ligne - 1][col - 1].isEstOccupe())
                    {
                        if ((listeCase[ligne][col].getJ() == joueur1) && (listeCase[ligne - 1][col - 1].getJ() == joueur1))
                        {
                            if(ligne+1==5)
                            {
                                if ((listeCase[ligne +1][col+1].isEstOccupe() == false) && (joueurPose == false))
                                {
                                    casePrise(ligne+1,col+1);
                                    joueurPose = true;
                                }
                            }

                            if (ligne<5)
                            {

                                if((listeCase[ligne +1][col+1].isEstOccupe() == false) && (joueurPose == false)&&(listeCase[ligne ][col+1].isEstOccupe()))
                                {
                                    casePrise(ligne+1,col+1);
                                    joueurPose = true;
                                }
                                if((listeCase[ligne -2][col-2].isEstOccupe() == false) && (joueurPose == false)&&(listeCase[ligne-1 ][col-2].isEstOccupe()))
                                {
                                    casePrise(ligne-2,col-2);
                                    joueurPose = true;
                                }
                            }

                        }
                    }
                }
            }
        }





        return joueurPose;
    }

    public boolean joueur1AligneJetonHorizontalementGDH(Joueur JoueurCourant)
    {
        boolean joueurPose=JoueurCourant.isaPoser();

        for(int ligne=0;ligne<6;ligne++)
        {
            for(int col=0;col<7;col++)
            {

                if((ligne>1 && ligne<5) &&((col<5)&&(col>0)))
                {
                    if(listeCase[ligne][col].isEstOccupe()&&listeCase[ligne-1][col+1].isEstOccupe()) {
                        if ((listeCase[ligne][col].getJ() == joueur1) && (listeCase[ligne - 1][col+1].getJ() == joueur1)) {

                            if ((listeCase[ligne - 2][col+2].isEstOccupe() == false) && (joueurPose == false)&&(listeCase[ligne -1 ][col+2].isEstOccupe())) {

                                casePrise(ligne-2,col+2);
                                joueurPose = true;
                            }

                        }
                    }
                }
                else if(ligne!=0 && col==0)
                {
                    if(listeCase[ligne][col].isEstOccupe()&&listeCase[ligne-1][col+1].isEstOccupe()) {
                        if ((listeCase[ligne][col].getJ() == joueur1) && (listeCase[ligne - 1][col+1].getJ() == joueur1)) {

                            if ((listeCase[ligne - 2][col+2].isEstOccupe() == false) && (joueurPose == false)&&(listeCase[ligne -1 ][col+2].isEstOccupe())) {

                                casePrise(ligne-2,col+2);
                                joueurPose = true;
                            }

                        }
                    }
                }
                else if(ligne >1  && col==4)
                {
                    if(listeCase[ligne][col].isEstOccupe()&&listeCase[ligne-1][col+1].isEstOccupe()) {
                        if ((listeCase[ligne][col].getJ() == joueur1) && (listeCase[ligne - 1][col+1].getJ() == joueur1)) {

                            if(ligne==5)
                            {
                                if ((listeCase[ligne - 2][col+2].isEstOccupe() == false) && (joueurPose == false)&&(listeCase[ligne -1 ][col+2].isEstOccupe())) {
                                    casePrise(ligne-2,col+2);
                                    joueurPose = true;
                                }
                            }

                        }
                    }
                }
                else if(col==6 && ligne<4)
                {
                    if(listeCase[ligne][col].isEstOccupe()&&listeCase[ligne+1][col-1].isEstOccupe()) {
                        if ((listeCase[ligne][col].getJ() == joueur1) && (listeCase[ligne +1][col-1].getJ() == joueur1)) {

                            if(ligne+2==5)
                            {
                                if ((listeCase[ligne + 2][col-2].isEstOccupe() == false) && (joueurPose == false)) {
                                    casePrise(ligne+2,col-2);
                                    joueurPose = true;
                                }
                            }
                            else
                            {
                                if ((listeCase[ligne + 2][col-2].isEstOccupe() == false) && (joueurPose == false)&&(listeCase[ligne +3 ][col-2].isEstOccupe())) {
                                    casePrise(ligne+2,col-2);
                                    joueurPose = true;
                                }
                            }

                        }
                    }
                }
            }
        }

        return joueurPose;
    }

    public boolean joueur1AligneJetonVerticalement(Joueur JoueurCourant)
    {
        boolean joueurPose=JoueurCourant.isaPoser();

        for(int ligne=0;ligne<6;ligne++)
        {
            for(int col=0;col<7;col++)
            {
                if(ligne>1)
                {

                    if(listeCase[ligne][col].isEstOccupe()&&listeCase[ligne-1][col].isEstOccupe())
                    {
                        if((listeCase[ligne][col].getJ()==joueur1)&&(listeCase[ligne-1][col].getJ()==joueur1))
                        {


                                if((listeCase[ligne-2][col].isEstOccupe()==false)&&(joueurPose==false))
                                {
                                    casePrise(ligne-2,col);

                                    joueurPose=true;
                                }
                            }
                        }
                    }
            }
        }

        return joueurPose;
    }

    public boolean joueur1AligneJetonHorizontalement(Joueur JoueurCourant)
    {
        boolean joueurPose=JoueurCourant.isaPoser();

        for(int ligne=0;ligne<6;ligne++)
        {
            for(int col=0;col<7;col++)
            {

                if((col>0)&&(col<5))
                {
                    if(listeCase[ligne][col].isEstOccupe()&&listeCase[ligne][col+1].isEstOccupe()) {
                        if ((listeCase[ligne][col].getJ() == joueur1) && (listeCase[ligne][col + 1].getJ() == joueur1)) {

                                if ((listeCase[ligne][col - 1].isEstOccupe() == false) && (joueurPose == false)) {

                                    if(ligne==5)
                                    {
                                        casePrise(ligne, col - 1);
                                        joueurPose = true;
                                    }
                                    else if((listeCase[ligne + 1][col - 1].isEstOccupe()))
                                    {
                                        casePrise(ligne, col - 1);
                                        joueurPose = true;
                                    }

                                }
                                if ((listeCase[ligne][col + 2].isEstOccupe() == false) && (joueurPose == false))
                                {

                                    if(ligne==5)
                                    {
                                        casePrise(ligne, col + 2);
                                        joueurPose = true;
                                    }
                                    else if(listeCase[ligne + 1][col + 2 ].isEstOccupe())
                                    {
                                        casePrise(ligne, col + 2);
                                        joueurPose = true;
                                    }

                                }
                            }
                        }
                    }
                    else if(col==0)
                    {
                        if(listeCase[ligne][col].isEstOccupe()&&listeCase[ligne][col+1].isEstOccupe())
                        {

                            if ((listeCase[ligne][col].getJ() == joueur1) && (listeCase[ligne][col + 1].getJ() == joueur1))
                            {
                                if ((listeCase[ligne][col + 2].isEstOccupe() == false) && (joueurPose == false))
                                {

                                    if(ligne==5)
                                    {
                                        casePrise(ligne, col + 2);
                                        joueurPose = true;
                                    }
                                    else if(listeCase[ligne + 1][col + 2 ].isEstOccupe())
                                    {
                                        casePrise(ligne, col + 2);
                                        joueurPose = true;
                                    }

                                }
                            }

                        }

                    }
                    else if(col==6)
                    {

                        if(listeCase[ligne][col-1].isEstOccupe()&&listeCase[ligne][col].isEstOccupe())
                        {
                            if ((listeCase[ligne][col-1].getJ() == joueur1) && (listeCase[ligne][col].getJ() == joueur1))
                            {

                                if ((listeCase[ligne][col - 2].isEstOccupe() == false) && (joueurPose == false)) {

                                    if(ligne==5)
                                    {
                                        casePrise(ligne, col - 2);
                                        joueurPose = true;
                                    }
                                    else if((listeCase[ligne + 1][col - 2].isEstOccupe()))
                                    {
                                        casePrise(ligne, col - 2);
                                        joueurPose = true;
                                    }

                                }
                            }

                        }

                    }

                }

            }

        return joueurPose;
    }

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    //////////////////////////////////////////////////////////////////////////////////////////////
    public boolean partieMatchNul()
    {
        boolean res = false;

        if((joueur1.getListeJeton().size()==0)&&(joueur2.getListeJeton().size()==0))
        {
            res=true;
        }

        return res;
    }

    public boolean partieFinie()
    {
        for(int i=0;i<6;i++)
        {
            for(int j=0;j<7;j++)
            {
                //Pions alignés dans lignes
                if(((listeCase[i][0].isEstOccupe())&&(listeCase[i][1].isEstOccupe())&&(listeCase[i][2].isEstOccupe())&&(listeCase[i][3].isEstOccupe()))
                 ||((listeCase[i][6].isEstOccupe())&&(listeCase[i][5].isEstOccupe())&&(listeCase[i][4].isEstOccupe())&&(listeCase[i][3].isEstOccupe()))
                 ||((listeCase[i][5].isEstOccupe())&&(listeCase[i][4].isEstOccupe())&&(listeCase[i][3].isEstOccupe())&&(listeCase[i][2].isEstOccupe()))
                 ||((listeCase[i][1].isEstOccupe())&&(listeCase[i][2].isEstOccupe())&&(listeCase[i][3].isEstOccupe())&&(listeCase[i][4].isEstOccupe())))
                {

                    if(((listeCase[i][0].getJ()==listeCase[i][1].getJ())&&(listeCase[i][2].getJ()==listeCase[i][3].getJ())&&(listeCase[i][0].getJ()==listeCase[i][3].getJ()))
                     ||((listeCase[i][1].getJ()==listeCase[i][2].getJ())&&(listeCase[i][3].getJ()==listeCase[i][4].getJ())&&(listeCase[i][1].getJ()==listeCase[i][4].getJ()))
                     ||((listeCase[i][2].getJ()==listeCase[i][3].getJ())&&(listeCase[i][4].getJ()==listeCase[i][5].getJ())&&(listeCase[i][2].getJ()==listeCase[i][5].getJ()))
                     ||((listeCase[i][3].getJ()==listeCase[i][4].getJ())&&(listeCase[i][5].getJ()==listeCase[i][6].getJ())&&(listeCase[i][3].getJ()==listeCase[i][6].getJ())))
                    {

                        terminee=true;
                        joueurGagnant=joueurCourant;
                    }
                }
                //Pions alignés dans colonnes
                if(((listeCase[5][j].isEstOccupe())&&(listeCase[4][j].isEstOccupe())&&(listeCase[3][j].isEstOccupe())&&(listeCase[2][j].isEstOccupe()))
                 ||((listeCase[0][j].isEstOccupe())&&(listeCase[1][j].isEstOccupe())&&(listeCase[2][j].isEstOccupe())&&(listeCase[3][j].isEstOccupe()))
                 ||((listeCase[1][j].isEstOccupe())&&(listeCase[2][j].isEstOccupe())&&(listeCase[3][j].isEstOccupe())&&(listeCase[4][j].isEstOccupe())))
                {
                    if(((listeCase[5][j].getJ()==listeCase[4][j].getJ())&&(listeCase[3][j].getJ()==listeCase[2][j].getJ())&&(listeCase[5][j].getJ()==listeCase[2][j].getJ()))
                     ||((listeCase[0][j].getJ()==listeCase[1][j].getJ())&&(listeCase[2][j].getJ()==listeCase[3][j].getJ())&&(listeCase[0][j].getJ()==listeCase[3][j].getJ()))
                     ||((listeCase[1][j].getJ()==listeCase[2][j].getJ())&&(listeCase[3][j].getJ()==listeCase[4][j].getJ())&&(listeCase[1][j].getJ()==listeCase[4][j].getJ())))
                    {
                        terminee=true;
                        joueurGagnant=joueurCourant;
                    }
                }
                //diagonales bas haut droite
                if((i>2)&&(j<4))
                {
                    if((listeCase[i][j].isEstOccupe()&&listeCase[i-1][j+1].isEstOccupe())&&(listeCase[i-2][j+2].isEstOccupe()&&listeCase[i-3][j+3].isEstOccupe())&&(listeCase[i][j].isEstOccupe()&&listeCase[i-3][j+3].isEstOccupe()))
                    {
                        if((listeCase[i][j].getJ()==listeCase[i-1][j+1].getJ())&&(listeCase[i-2][j+2].getJ()==listeCase[i-3][j+3].getJ())&&(listeCase[i][j].getJ()==listeCase[i-3][j+3].getJ()))
                        {
                            terminee=true;
                            joueurGagnant=joueurCourant;
                        }
                    }
                }
                //diagonales bas  haut gauche marche pas
                if((i<3)&&(j>2))
                {
                    if(listeCase[i][j-3].isEstOccupe()&&listeCase[i+1][j-2].isEstOccupe()&&listeCase[i+2][j-1].isEstOccupe()&&listeCase[i+3][j].isEstOccupe())
                    {
                        if((listeCase[i][j-3].getJ()==listeCase[i+1][j-2].getJ())&&(listeCase[i+2][j-1].getJ()==listeCase[i+3][j].getJ())&&(listeCase[i][j-3].getJ()==listeCase[i+3][j].getJ()))
                        {
                            terminee=true;
                            joueurGagnant=joueurCourant;
                        }
                    }
                }

            }
        }


        return terminee;
    }

    /////////////////////////////////////////////////////////////////////////////////////////////
    public void casePrise(int ligne, int colonne)
    {

            listeCase[ligne][colonne].setEstOccupe(true);
            listeCase[ligne][colonne].setJ(joueurCourant);

            joueurCourant.setListeJetonJoue(new Jeton(joueurCourant.getCouleurJeton()));
            joueurCourant.setListeJeton();


    }
    public void iaRandom()
    {
        int colonne = rand.nextInt(7);
        poserJeton(joueurCourant,colonne);

    }

    public void cooPoseJoueur(int ligne, int col)
    {
      System.out.println(""+joueurCourant.getType()+" : "+col+"/"+ligne);

    for(int l=0;l<6;l++)
        {
            for (int c = 0; c < 7; c++)
            {
                if(listeCase[l][c].isEstOccupe())
                {
                    System.out.print(listeCase[l][c].getJ().getNom()+" | ");
                }
                else
                {
                    System.out.print("vide | ");
                }
            }
            System.out.print("\n");
        }
        System.out.print("\n");
    }
}
