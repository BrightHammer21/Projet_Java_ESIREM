package IHM.MenuJeu.ZonesJeu;

import IHM.MenuJeu.FenetrePartieFinie.fenetreMatchNul;
import IHM.MenuJeu.FenetrePartieFinie.fenetreMatchNulIA;
import IHM.MenuJeu.FenetrePartieFinie.fenetrePartieFinie;
import IHM.MenuJeu.FenetrePartieFinie.fenetrePartieFinieIA;
import IHM.PlateauJeu;
import Métier.Puissance4;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class ZoneTourSuivant extends Parent {

    private Pane tourSuivant;
    private ZoneInfoJoueur info;
    private ZoneJoueur1 zoneJoueur1;
    private ZoneJoueur2 zoneJoueur2;
    private ZoneJeu zoneJeu;
    private Puissance4 p;
    private ZonePoserJeton poserJeton;
    private boolean partieFinieMatchNul;
    private boolean partieFinie;
    private Stage cett_fenetre;

    public ZoneTourSuivant(ZoneInfoJoueur info, Puissance4 p, ZoneJoueur1 zoneJoueur1, ZoneJoueur2 zoneJoueur2, ZoneJeu zoneJeu,Stage cette_fenetre)
    {
        this.info=info;
        this.zoneJoueur1=zoneJoueur1;
        this.zoneJoueur2=zoneJoueur2;
        this.zoneJeu=zoneJeu;
        this.p=p;
        this.cett_fenetre=cette_fenetre;

        partieFinie=false;
        partieFinieMatchNul=false;
    }

    public void tourSuivant( ZonePoserJeton poserJeton)
    {
        tourSuivant = new Pane();
        this.poserJeton = poserJeton;

        /////////////////////////////////////////////////////////////////BOUTONS
        Button b_tourSuivant = new Button("TOUR SUIVANT");
        b_tourSuivant.setLayoutY(760);
        b_tourSuivant.setLayoutX(560);
        b_tourSuivant.setTextFill(Color.WHITE);

        b_tourSuivant.setFont(Font.font("Verdana", FontWeight.BOLD, 14));
        b_tourSuivant.setPrefSize(150,30);
        tourSuivant.getChildren().add(b_tourSuivant);

        if(p.getJoueurCourant().isaPoser()==true)
        {
            //Si le joueur courant a posé son jeton, le tour suivant se déverouille
            b_tourSuivant.setBackground(new Background(new BackgroundFill(Color.GREEN,null,null)));

            b_tourSuivant.setOnAction(new EventHandler<ActionEvent>(){
                @Override
                public void handle(ActionEvent event) {

                    if(p.getJoueurCourant()==p.getJoueur1())
                    {
                        p.setJoueurCourant(p.getJoueur2());
                        p.getJoueur1().setaPoser(false);

                        if(p.getJoueurCourant().getType()=="IA")
                        {
                            p.iaPose(p.getJoueurCourant());

                            partieFinieMatchNul=p.partieMatchNul();
                            partieFinie=p.partieFinie();

                            //////////////////////////////SI PARTIE FINIE
                            if(partieFinieMatchNul==true)
                            {
                                Stage nouvelle_fenetre = new Stage();
                                fenetreMatchNulIA matchNul_fenetre = new fenetreMatchNulIA(cett_fenetre,nouvelle_fenetre,p);
                                Scene nouvelle_scene = new Scene(matchNul_fenetre,630,380);

                                nouvelle_fenetre.setScene(nouvelle_scene);
                                nouvelle_fenetre.show();

                            }
                            else if(partieFinie==true)
                            {
                                Stage nouvelle_fenetre = new Stage();
                                fenetrePartieFinieIA fini_fenetre = new fenetrePartieFinieIA(cett_fenetre,nouvelle_fenetre,p);
                                Scene nouvelle_scene = new Scene(fini_fenetre,630,380);

                                nouvelle_fenetre.setScene(nouvelle_scene);
                                nouvelle_fenetre.show();

                            }

                            p.getJoueurCourant().setaPoser(false);
                            p.setJoueurCourant(p.getJoueur1());

                            detruireZone();

                        }

                        detruireZone();
                    }
                    else
                    {

                        p.setJoueurCourant(p.getJoueur1());
                        p.getJoueur2().setaPoser(false);
                        detruireZone();
                    }


                }
            });
        }
        else
        {
            b_tourSuivant.setBackground(new Background(new BackgroundFill(Color.GREY,null,null)));
        }


        //AJOUT A LA SCENE
        this.getChildren().add(tourSuivant);
    }

    public void detruireTourSuivant()
    {
        this.getChildren().removeAll(tourSuivant);
    }

    public void detruireZone()
    {
        info.detruireInfoJoueur();
        info.genererInfoJoueur();
        zoneJeu.detruireCase();
        zoneJeu.genererCase();
        poserJeton.detruireBoutonsPose();
        poserJeton.genererBoutonsPose();
        zoneJoueur2.supprimerJoueur2();
        zoneJoueur2.générerPion();
        detruireTourSuivant();
        tourSuivant(poserJeton);
    }
}
