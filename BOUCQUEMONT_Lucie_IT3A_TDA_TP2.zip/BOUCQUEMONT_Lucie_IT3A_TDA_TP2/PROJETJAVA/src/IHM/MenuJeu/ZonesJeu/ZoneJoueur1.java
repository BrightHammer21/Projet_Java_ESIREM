package IHM.MenuJeu.ZonesJeu;

import Entités.Joueur;
import IHM.PlateauJeu;
import Métier.Puissance4;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;


public class ZoneJoueur1 extends Parent {

    private Pane infoJoueur1;
    private PlateauJeu jeu;
    private Joueur joueur1;
    private ZoneJeu zonejeu;

    private int compteur=0;
    private int posY=250;
    private int posX=45;

    //Constructeur
    public ZoneJoueur1(PlateauJeu jeu, Joueur joueur1, Puissance4 p, ZoneJeu zonejeu)
    {
        this.jeu=jeu;
        this.joueur1=joueur1;
        this.zonejeu=zonejeu;

        générerPion();

    }


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public void générerPion()
    {
        //CREATION DU PANE
        infoJoueur1 = new Pane();

        //RECTANGLE CONTOUR
        Rectangle rectangle = new Rectangle();
        rectangle.setHeight(410);
        rectangle.setWidth(150);
        rectangle.setX(20);
        rectangle.setY(170);
        rectangle.setFill(Color.TRANSPARENT);
        rectangle.setStroke(Color.BLACK);

        ///LABEL JOUEUR 1
        Button l_joueur1 = new Button(joueur1.getNom());
        l_joueur1.setLayoutX(20);
        l_joueur1.setLayoutY(170);
        l_joueur1.setPrefSize(150,50);
        l_joueur1.setTextFill(Color.WHITE);
        l_joueur1.setBackground(new Background(new BackgroundFill(joueur1.getCouleurJeton(),null,null)));


        l_joueur1.setFont(Font.font("Verdana", FontWeight.BOLD, 14));

        //JETONS
        for(int i=0; i<joueur1.getListeJeton().size();i++) {
            Circle c = new Circle();
            c.setFill(joueur1.getCouleurJeton());
            c.setRadius(20);
            c.setStroke(Color.BLACK);
            c.setStrokeWidth(1);

            if (compteur == 3) {
                compteur = 0;
                posY += 50;
                posX = 45;
            }
            c.setLayoutX(posX);
            c.setLayoutY(posY);

            posX += 50;
            compteur++;

            infoJoueur1.getChildren().add(c);
        }

        posY=250;
        posX=45;
        compteur=0;

        //AJOUT AU PANE
        infoJoueur1.getChildren().add(rectangle);
        infoJoueur1.getChildren().add(l_joueur1);


        //AJOUT A LA SCENE
        this.getChildren().add(infoJoueur1);
    }


    public void supprimerJoueur1()
    {
        this.getChildren().removeAll(infoJoueur1);
    }
}
