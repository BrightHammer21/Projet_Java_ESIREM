package IHM.MenuJeu;

import Métier.Puissance4;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.net.URL;

public class Regle extends Parent {
    public Regle(Stage fenetrePartie, Stage cette_fenetre) {

        //TITRE
        Button menu = new Button("REGLE DU JEU");
        menu.setPrefSize(620, 60);
        menu.setLayoutX(0);
        menu.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 30));
        menu.setTextFill(Color.WHITE);
        menu.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null)));


        //TEXTE
        Text titre = new Text();
        titre.setText("Règles du jeu du Puissance 4");
        titre.setX(20);
        titre.setY(90);
        titre.setFill(Color.rgb(234,108,21));
        titre.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 18));

        Text commentJouer = new Text();
        commentJouer.setText("1. Comment jouer : \n  Deux modes");
        commentJouer.setX(20);
        commentJouer.setY(120);
        commentJouer.setFont(Font.font("Verdana", FontWeight.BOLD, 16));


        Text textJouer = new Text();
        textJouer.setText("Joueur contre joueur ou vous jouez contre un ami !\nEn solo si vous avez envie de jouer contre une IA !");
        textJouer.setX(30);
        textJouer.setY(160);
        textJouer.setFont(Font.font("Verdana", FontWeight.NORMAL, 16));

        Text textJouer2 = new Text();
        textJouer2.setText("Ensuite la même mécanique s'appliquera quelque soit votre choix :");
        textJouer2.setX(30);
        textJouer2.setY(200);
        textJouer2.setFont(Font.font("Verdana", FontWeight.NORMAL, 16));

        //image
        URL logo = getClass().getResource("commentJouer.png");
        Image image = new Image(logo.toExternalForm());
        ImageView imageViewJouer = new ImageView(image);


        imageViewJouer.setFitWidth(610);
        imageViewJouer.setLayoutX(5);
        imageViewJouer.setLayoutY(220);
        imageViewJouer.setPreserveRatio(true);


        ////////////////////////////
        Text commentGagner = new Text();
        commentGagner.setText("2. Comment gagner : ");
        commentGagner.setX(20);
        commentGagner.setY(570);
        commentGagner.setFont(Font.font("Verdana", FontWeight.BOLD, 16));

        Text textgagner = new Text();
        textgagner.setText("Pour gagner, rien de plus simple ! Il suffit d'aligner 4 de vos jetons !\nPour ça, trois manières pour y arriver :");
        textgagner.setX(30);
        textgagner.setY(600);
        textgagner.setFont(Font.font("Verdana", FontWeight.NORMAL, 16));
        //image
        URL logo2 = getClass().getResource("alignementPion.png");
        Image image2 = new Image(logo2.toExternalForm());
        ImageView imageViewAlignement = new ImageView(image2);


        imageViewAlignement.setFitWidth(610);
        imageViewAlignement.setLayoutX(5);
        imageViewAlignement.setLayoutY(620);
        imageViewAlignement.setPreserveRatio(true);


        /////////////////////BOUTON
        Button b_retourMenu=new Button("MENU PRINCIPAL");
        b_retourMenu.setLayoutX(150);
        b_retourMenu.setLayoutY(825);
        b_retourMenu.setTextFill(Color.WHITE);
        b_retourMenu.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 18));
        b_retourMenu.setPrefSize(300,40);

        b_retourMenu.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 18));
        b_retourMenu.setTextFill(Color.WHITE);
        b_retourMenu.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null)));
        b_retourMenu.setOnMouseEntered(e->b_retourMenu.setBackground(new Background(new BackgroundFill(Color.rgb(33,232,46),null, null))));
        b_retourMenu.setOnMouseExited(e->b_retourMenu.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null))));


        b_retourMenu.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {
                cette_fenetre.close();

            }
        });


        this.getChildren().add(b_retourMenu);
        this.getChildren().add(menu);
        this.getChildren().add(titre);
        this.getChildren().add(commentJouer);
        this.getChildren().add(commentGagner);
        this.getChildren().add(imageViewAlignement);
        this.getChildren().add(imageViewJouer);
        this.getChildren().add(textgagner);
        this.getChildren().add(textJouer);
        this.getChildren().add(textJouer2);



    }
}
