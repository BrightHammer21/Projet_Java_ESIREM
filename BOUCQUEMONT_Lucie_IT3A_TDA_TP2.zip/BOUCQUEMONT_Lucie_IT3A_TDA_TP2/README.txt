PROJET --- PUISSANCE 4 -----------------------------------------------------------------

But : Vainquez votre adversaire en lignant 4 de votre jetons dans le plateau.
Attention :  Comme dans le vrai puissance 4, les jetons s'empilent et une fois posés
	     il est impossible de les récupérer.
	     Comme pour le vrai jeu, pour gagner, il suffit de les aligner verticalement
	     , horizontalement ou en diagonale.
Dans ce jeu, vous pouvez jouer contre votre ami u contre une IA bloquante. 
Arrivez-vous à gagner ? 

Note : un exécutable a été créé. Il se trouve à l'addresse suivante :
				out/artifacts/PROJETJAVA_jar

---------------Procédure pour tester la réalisation ------------------------------------
----------------------------------------------------------------------------------------

1.Lancez le jeu. Un menu apparaitra avec différentes options.
	- Humain vs Humain : en cliquant sur ce bouton, vous pourrez jouer contre votre
			     ami.
	- Solo : en cliquant sur ce menu, vous affronterez l'IA bloquante.
	- ? : ce bouton vous résumera les règles du jeu et vous spécifiera où cliquer
		durant la partie.
	- Quitter : ce bouton vous permettra de quitter le jeu.

2. Une fois l'un des deux modes choisis, une fenêtre apparaitra permettant de choisir un
   un nom et une couleur pour les joueurs. (Un nom par défaut et une couleur par défaut 
   étant déjà sélectionné).
   Ensuite cliquez sur "Commencer Partie". La fenêtre de la partie apparaitra alors.

3.Pour poser les jetons, il suffit de cliquer sur un des boutons positionné au dessus de
  chaque colonne. 
  ATTENTION ! Une fois posé, vous ne pouvez pas revenir en arrière, sinon, ça serait trop 
	      simple.
  Vous pourrez ensuite passer au tour suivant. (Cette fonctionnalité ne sera pas activée
  tant que vous n'avez pas posé votre jeton.)
	- En Humain vs Humain, ce sera alors au tour du joueur2. La même mécanique 
	  s'appliquera.
	- En solo, l'IA jouera automatiquement et ce sera de nouveau à votre tour.

  Un menu sera accessible durant la partie vous permettant de :
	- Retourner au jeu
	- Recommencer la partie
	- Aller au menu principal
	- Quitter le jeu

4. Une fenêtre apparaitra en cas de victoire ou de match nul. Vous pourrez :
	- Recommencer la partie
	- Retourner au menu
	- Quitter le jeu