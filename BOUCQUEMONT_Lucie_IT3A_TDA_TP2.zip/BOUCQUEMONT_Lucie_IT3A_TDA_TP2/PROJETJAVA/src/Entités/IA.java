package Entités;

import javafx.scene.paint.Color;

public class IA extends Joueur {

    public IA(String nom, Color couleur)
    {
        super(nom,couleur);
    }

    @Override
    public String getType() {
        return "IA";
    }
}
