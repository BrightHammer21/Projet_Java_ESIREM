package IHM.MenuJeu.FenetrePartieFinie;

import IHM.MenuJeu.Accueil;
import IHM.MenuJeu.FenetreChoixJeu.HumainVsHumain;
import IHM.PlateauJeu;
import Métier.Puissance4;
import Métier.initialisationPartie;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;


public class fenetreMatchNul extends Parent {

    public fenetreMatchNul(Stage ancienne_fentre, Stage cette_fenetre, Puissance4 p)
    {
        Rectangle rectangle = new Rectangle();
        rectangle.setWidth(620);
        rectangle.setHeight(370);
        rectangle.setFill(Color.TRANSPARENT);
        rectangle.setStroke(Color.rgb(239,121,15));
        rectangle.setX(5);



        Button matchnul=new Button("MATCH NUL !!!!!!!!!!!");
        matchnul.setPrefSize(620,60);
        matchnul.setLayoutX(5);
        matchnul.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 40));
        matchnul.setTextFill(Color.WHITE);
        matchnul.setBackground(new Background(new BackgroundFill(Color.rgb(239,121,15), null, null)));

        Label text = new Label("Que souhaitez-vous faire ?");
        text.setLayoutY(130);
        text.setLayoutX(130);
        text.setFont(Font.font("Verdana", FontWeight.BOLD, 25));

        Button b_FermerJeu=new Button("QUITTER LE JEU");
        b_FermerJeu.setLayoutX(10);
        b_FermerJeu.setLayoutY(300);
        b_FermerJeu.setTextFill(Color.WHITE);
        b_FermerJeu.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 18));
        b_FermerJeu.setPrefSize(300,40);


        Button b_retourMenu=new Button("MENU");
        b_retourMenu.setLayoutX(320);
        b_retourMenu.setLayoutY(300);
        b_retourMenu.setTextFill(Color.WHITE);
        b_retourMenu.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 18));
        b_retourMenu.setPrefSize(300,40);


        Button b_nouvellePartie = new Button("NOUVELLE PARTIE");
        b_nouvellePartie.setLayoutX(175);
        b_nouvellePartie.setLayoutY(200);
        b_nouvellePartie.setTextFill(Color.WHITE);
        b_nouvellePartie.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null)));
        b_nouvellePartie.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 18));
        b_nouvellePartie.setPrefSize(300,40);


        /////////////////////////////////////////////////////////////////////// HOVER
        b_nouvellePartie.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null)));
        b_nouvellePartie.setOnMouseEntered(e->b_nouvellePartie.setBackground(new Background(new BackgroundFill(Color.rgb(33,232,46), null, null))));
        b_nouvellePartie.setOnMouseExited(e->b_nouvellePartie.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null))));


        b_FermerJeu.setBackground(new Background(new BackgroundFill(Color.rgb(188,10,10), null, null)));
        b_FermerJeu.setOnMouseEntered(e->b_FermerJeu.setBackground(new Background(new BackgroundFill(Color.RED, null, null))));
        b_FermerJeu.setOnMouseExited(e->b_FermerJeu.setBackground(new Background(new BackgroundFill(Color.rgb(188,10,10), null, null))));

        b_retourMenu.setBackground(new Background(new BackgroundFill(Color.rgb(188,10,10), null, null)));
        b_retourMenu.setOnMouseEntered(e->b_retourMenu.setBackground(new Background(new BackgroundFill(Color.RED, null, null))));
        b_retourMenu.setOnMouseExited(e->b_retourMenu.setBackground(new Background(new BackgroundFill(Color.rgb(188,10,10), null, null))));



        //////////////////////////////////////////////////////////////////////ACTION BOUTON
        b_FermerJeu.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {
                ancienne_fentre.close();
                cette_fenetre.close();
            }
        });

        b_retourMenu.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {

                cette_fenetre.setTitle("Puissance 4");
                Group root = new Group();
                Accueil accueil = new Accueil(cette_fenetre);
                cette_fenetre.setScene(new Scene(root, 350, 350));

                root.getChildren().add(accueil);
                cette_fenetre.show();

                ancienne_fentre.close();
            }
        });


        b_nouvellePartie.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {
                //initialisation de la partie
                initialisationPartie partie = new initialisationPartie(p.getJoueur1().getNom(),p.getJoueur2().getNom(), p.getJoueur1().getCouleurJeton(), p.getJoueur2().getCouleurJeton());
                Puissance4 p=new Puissance4(partie.getJoueur1(),partie.getJoueur2(),partie.getPlateauCase());

                //création du plateau
                Stage nouveau_plateau = new Stage();
                PlateauJeu jeu = new PlateauJeu(cette_fenetre, nouveau_plateau, partie.getJoueur1(),partie.getJoueur2(), partie.getPlateauCase(), p);
                Scene scene = new Scene(jeu, 1275, 750);
                nouveau_plateau.setScene(scene);
                nouveau_plateau.show();

                ancienne_fentre.close();
                cette_fenetre.close();

            }
        });

        ///EMPEPCHE LA FENETRE D'ETRE FERMEE

        cette_fenetre.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent event) {
                event.consume();
            }
        });

        this.getChildren().add(rectangle);
        this.getChildren().add(matchnul);
        this.getChildren().add(text);
        this.getChildren().add(b_FermerJeu);
        this.getChildren().add(b_retourMenu);
        this.getChildren().add(b_nouvellePartie);
    }

}
