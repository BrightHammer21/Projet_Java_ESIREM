package IHM.MenuJeu.FenetreChoixJeu;

import IHM.PlateauJeu;
import Métier.Puissance4;
import Métier.initialisationPartie;
import Métier.initialisationPartieIA;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class Solo extends Parent {

    public Solo(Stage primaryStage, Stage nouvelle_fenetre)
    {
        Button b_titre=new Button("NOUVELLE PARTIE SOLO");
        b_titre.setLayoutX(10);
        b_titre.setLayoutY(10);
        b_titre.setPrefSize(590,60);
        b_titre.setFont(Font.font("Verdana", FontWeight.BOLD, 22));
        b_titre.setTextFill(Color.WHITE);
        b_titre.setBackground(new Background(new BackgroundFill(Color.rgb(198,5,5), null, null)));
        b_titre.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID,null,null)));


        //LABELS DES JOUEURS
        Label l_joueur1 = new Label("Joueur 1 :");
        Label l_couleurJoueur1 = new Label("Couleur des jetons : ");
        Label l_joueur2 = new Label("IA : IA");
        Label l_couleurJoueur2 = new Label("Couleur des jetons : ");

        l_joueur1.setFont(Font.font("Verdana", FontWeight.SEMI_BOLD, 15));
        l_couleurJoueur1.setFont(Font.font("Verdana", FontWeight.SEMI_BOLD, 15));
        l_joueur2.setFont(Font.font("Verdana", FontWeight.SEMI_BOLD, 15));
        l_couleurJoueur2.setFont(Font.font("Verdana", FontWeight.SEMI_BOLD, 15));

        l_joueur1.setLayoutX(30);
        l_joueur1.setLayoutY(115);
        l_couleurJoueur1.setLayoutY(115);
        l_couleurJoueur1.setLayoutX(320);

        l_joueur2.setLayoutX(30);
        l_joueur2.setLayoutY(215);
        l_couleurJoueur2.setLayoutY(215);
        l_couleurJoueur2.setLayoutX(320);


        Label l_erreur=new Label("");
        l_erreur.setFont(Font.font("Verdana", FontWeight.SEMI_BOLD, 15));

        l_erreur.setLayoutY(75);
        l_erreur.setLayoutX(100);
        l_erreur.setTextFill(Color.RED);


        //Rectangle
        Rectangle r_contour = new Rectangle();
        r_contour.setHeight(325);
        r_contour.setWidth(590);
        r_contour.setLayoutX(10);
        r_contour.setLayoutY(10);
        r_contour.setStroke(Color.BLACK);
        r_contour.setStrokeWidth(1);
        r_contour.setFill(Color.TRANSPARENT);

        /////////////////////////////////////////////////////////////couleur joueur
        ComboBox cb_couleurJ1 = new ComboBox();
        cb_couleurJ1.getItems().addAll(
                "    rouge",
                "    vert",
                "    bleu",
                "    violet",
                "    orange",
                "    rose"
        );
        cb_couleurJ1.getSelectionModel().selectFirst();
        cb_couleurJ1.setLayoutX(480);
        cb_couleurJ1.setLayoutY(110);
        cb_couleurJ1.setBackground(new Background(new BackgroundFill(Color.rgb(239,227,227), null, null)));
        cb_couleurJ1.setOnMouseEntered(e->cb_couleurJ1.setBackground(new Background(new BackgroundFill(Color.rgb(204,202,202), null, null))));
        cb_couleurJ1.setOnMouseExited(e->cb_couleurJ1.setBackground(new Background(new BackgroundFill(Color.rgb(239,227,227), null, null))));



        Rectangle r = new Rectangle();
        r.setFill(couleurJeton((String)cb_couleurJ1.getValue()));
        r.setLayoutX(487);
        r.setLayoutY(121);

        r.setHeight(11);
        r.setWidth(11);


        cb_couleurJ1.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {

                r.setFill(couleurJeton((String)cb_couleurJ1.getValue()));

            }
        });




        ComboBox cb_couleurIA = new ComboBox();
        cb_couleurIA.getItems().addAll(
                "    bleu",
                "    rouge",
                "    vert",
                "    violet",
                "    orange",
                "    rose"
        );
        cb_couleurIA.getSelectionModel().selectFirst();
        cb_couleurIA.setLayoutX(480);
        cb_couleurIA.setLayoutY(210);
        cb_couleurIA.setBackground(new Background(new BackgroundFill(Color.rgb(239,227,227), null, null)));
        cb_couleurIA.setOnMouseEntered(e->cb_couleurIA.setBackground(new Background(new BackgroundFill(Color.rgb(204,202,202), null, null))));
        cb_couleurIA.setOnMouseExited(e->cb_couleurIA.setBackground(new Background(new BackgroundFill(Color.rgb(239,227,227), null, null))));



        Rectangle r2 = new Rectangle();
        r2.setFill(couleurJeton((String)cb_couleurIA.getValue()));
        r2.setLayoutX(487);
        r2.setLayoutY(221);

        r2.setHeight(11);
        r2.setWidth(11);


        cb_couleurIA.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {

                r2.setFill(couleurJeton((String)cb_couleurIA.getValue()));

            }
        });

        //TextField
        TextField nomJoueur1 = new TextField("joueur1");
        nomJoueur1.setLayoutX(110);
        nomJoueur1.setLayoutY(110);



/////////////////////////////////////////////////////////////////////////////BOUTONS
        //BOUTONS MENU PRINCIPAL ET COMMENCER PARTIE
        Button menu_principal = new Button("MENU PRINCIPAL");
        Button commencer_partie = new Button("COMMENCER PARTIE");

        //POSITION
        menu_principal.setLayoutX(30);
        menu_principal.setLayoutY(290);
        commencer_partie.setLayoutX(330);
        commencer_partie.setLayoutY(290);

        //TAILLE BOUTONS
        menu_principal.setPrefSize(250,30);
        commencer_partie.setPrefSize(250,30);

        menu_principal.setTextFill(Color.WHITE);
        menu_principal.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 18));
        commencer_partie.setTextFill(Color.WHITE);
        commencer_partie.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 18));

        commencer_partie.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null)));
        commencer_partie.setOnMouseEntered(e->commencer_partie.setBackground(new Background(new BackgroundFill(Color.rgb(33,232,46), null, null))));
        commencer_partie.setOnMouseExited(e->commencer_partie.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null))));



        menu_principal.setBackground(new Background(new BackgroundFill(Color.rgb(188,10,10), null, null)));
        menu_principal.setOnMouseEntered(e->menu_principal.setBackground(new Background(new BackgroundFill(Color.RED, null, null))));
        menu_principal.setOnMouseExited(e->menu_principal.setBackground(new Background(new BackgroundFill(Color.rgb(188,10,10), null, null))));

////////////////////////////////////////////////////////////////////////////ACTIONS

        //MENU PRINCIPAL
        menu_principal.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {
                primaryStage.show();
                nouvelle_fenetre.close() ;

            }
        });


        //COMMENCER PARTIE
        commencer_partie.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                if((nomJoueur1.getText().equals("IA")||nomJoueur1.getText().equals("ia"))&&(couleurJeton((String)cb_couleurJ1.getValue()).equals(couleurJeton((String)cb_couleurIA.getValue()))))
                {
                    l_erreur.setText("ATTENTION : entrez une couleur et un nom différent pour chaque joueur");
                    l_erreur.setLayoutX(30);

                }
                else if(nomJoueur1.getText().equals("IA")||nomJoueur1.getText().equals("ia"))
                {
                    l_erreur.setText("ATTENTION : entrez un nom différent pour chaque joueur");
                }
                else if(couleurJeton((String)cb_couleurJ1.getValue()).equals(couleurJeton((String)cb_couleurIA.getValue())))
                {
                    l_erreur.setText("ATTENTION : entrez une couleur différente pour chaque joueur");
                    l_erreur.setLayoutX(70);
                }
                else
                    {
                    //initialisation de la partie
                     initialisationPartieIA partie = new initialisationPartieIA(nomJoueur1.getText(),"IA", couleurJeton((String)cb_couleurJ1.getValue()), couleurJeton((String)cb_couleurIA.getValue()));
                     Puissance4 p = new Puissance4(partie.getJoueur1(), partie.getJoueurIA(), partie.getPlateauCase());

                    //création du plateau
                    Stage nouveau_plateau = new Stage();
                    PlateauJeu jeu = new PlateauJeu(primaryStage, nouveau_plateau, partie.getJoueur1(), partie.getJoueurIA(), partie.getPlateauCase(), p);
                    Scene scene = new Scene(jeu, 1275, 750);
                    nouveau_plateau.setScene(scene);
                    nouveau_plateau.show();

                    nouvelle_fenetre.close();
                }

            }
        });

////////BLOCAGE REDUCTION

        nouvelle_fenetre.setMinWidth(630);
        nouvelle_fenetre.setMinHeight(390);

        nouvelle_fenetre.setMaxWidth(630);
        nouvelle_fenetre.setMaxHeight(390);

        //AJOUT A LA SCENE
        this.getChildren().add(r_contour);
        this.getChildren().add(b_titre);
        this.getChildren().add(l_joueur1);
        this.getChildren().add(l_couleurJoueur1);
        this.getChildren().add(nomJoueur1);
        this.getChildren().add(l_joueur2);
        this.getChildren().add(l_couleurJoueur2);
        this.getChildren().add(menu_principal);
        this.getChildren().add(commencer_partie);
        this.getChildren().add(l_erreur);

        this.getChildren().add(cb_couleurJ1);
        this.getChildren().add(r);
        this.getChildren().add(cb_couleurIA);
        this.getChildren().add(r2);
    }

    public Color couleurJeton(String i)
    {

        Color couleur;



        switch (i){
            case "    rouge" : couleur = Color.rgb(242,22,22);

                break;
            case "    vert" : couleur = Color.rgb(26,170,39);
                break;
            case "    bleu" : couleur = Color.rgb(77,157,244);
                break;
            case "    violet" : couleur = Color.rgb(126,37,147);
                break;
            case "    orange" : couleur = Color.rgb(232,105,49);
                break;
            case "    rose" : couleur = Color.rgb(241,125,244);
                break;
            default: couleur = Color.AZURE;
        }



        return couleur;
    }
}
