package Entités;

import javafx.scene.paint.Color;

public class Jeton {
    //Attribut
    private Color couleurJeton;
    private Coordonnées coo;

    public Jeton(Color c)
    {
        couleurJeton=c;
        coo = null;
    }

    public Coordonnées getCoo() {
        return coo;
    }

    public void setCoo(Coordonnées coo) {
        this.coo = coo;
    }

}
