package Métier;

import Entités.Coordonnées;
import Entités.Humain;
import Entités.Joueur;
import javafx.scene.paint.Color;

public class initialisationPartie {

    protected Joueur joueur1;
    protected Joueur joueur2;
    protected Case[][] plateauCase;
    private int nbLignes=6;
    private int nbColonne=7;
    private Puissance4 p;

    public initialisationPartie(String nomJoueur1, String nomJoueur2, Color couleurJ1, Color couleurJ2)
    {
        joueur1=new Humain(nomJoueur1,couleurJ1);
        joueur2=new Humain(nomJoueur2,couleurJ2);



        plateauCase = new Case[nbLignes][nbColonne];


        for(int i=0;i<6;i++) {
            for (int j = 0; j < 7; j++) {
                Coordonnées coo = new Coordonnées(i, j);
                plateauCase[i][j] = new Case(coo);

            }
        }
    }

    public Joueur getJoueur1() {
        return joueur1;
    }

    public Joueur getJoueur2() {
        return joueur2;
    }

    public Case[][] getPlateauCase() {
        return plateauCase;
    }

    public Puissance4 getP() {
        return p;
    }


}
