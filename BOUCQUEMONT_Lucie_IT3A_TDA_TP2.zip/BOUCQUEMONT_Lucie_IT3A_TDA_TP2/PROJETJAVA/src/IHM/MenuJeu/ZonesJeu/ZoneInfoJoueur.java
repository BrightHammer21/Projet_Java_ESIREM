package IHM.MenuJeu.ZonesJeu;

import IHM.MenuJeu.FenetrePartieFinie.fenetreMatchNulIA;
import IHM.MenuJeu.FenetrePartieFinie.menuJeu;
import Métier.Puissance4;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class ZoneInfoJoueur extends Parent {

    private Pane zoneInfoJoueur;
    private Puissance4 p;

    public ZoneInfoJoueur(Puissance4 p)
    {
        this.p=p;

        genererInfoJoueur();

    }

    public void genererInfoJoueur()
    {
        zoneInfoJoueur = new Pane();


        //information sur le joueur courant
        Rectangle r_Info = new Rectangle();
        r_Info.setHeight(40);
        r_Info.setWidth(1230);
        r_Info.setX(20);
        r_Info.setY(10);
        r_Info.setFill(p.getJoueurCourant().getCouleurJeton());
        r_Info.setStroke(Color.BLACK);


        //NOM DU JOUEUR EN COURS
        Label l_nomJoueurCourant = new Label("TOUR DE "+p.getJoueurCourant().getNom().toUpperCase());
        l_nomJoueurCourant.setLayoutY(20);
        l_nomJoueurCourant.setLayoutX(520);
        l_nomJoueurCourant.setFont(Font.font("Verdana", FontWeight.BOLD, 20));
        l_nomJoueurCourant.setTextFill(Color.WHITE);

        /////////////////////////////////////////////////////////////////////

        zoneInfoJoueur.getChildren().add(r_Info);
        zoneInfoJoueur.getChildren().add(l_nomJoueurCourant);



        //AJOUT A LA SCENE
        this.getChildren().add(zoneInfoJoueur);

    }

    public void detruireInfoJoueur()
    {
        this.getChildren().removeAll(zoneInfoJoueur);
    }
}
