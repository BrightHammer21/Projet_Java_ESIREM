package IHM.MenuJeu;

import IHM.MenuJeu.FenetreChoixJeu.HumainVsHumain;
import IHM.MenuJeu.FenetreChoixJeu.Solo;
import IHM.MenuJeu.FenetrePartieFinie.menuJeu;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.net.URL;


public class Accueil extends Parent {

    //CONSTRUCTEUR
    public Accueil(Stage primaryStage)
    {

          //image
        URL logo = getClass().getResource("fond.png");
        Image image = new Image(logo.toExternalForm());
        ImageView imageView = new ImageView(image);


        imageView.setFitWidth(350);
        imageView.setLayoutX(0);
        imageView.setPreserveRatio(true);

        //BOUTONS
        Button humainvsHumain = new Button("HUMAIN VS HUMAIN");
        Button solo = new Button("SOLO");
        Button quitter = new Button("QUITTER");


        Button b_help = new Button("?");
        b_help.setLayoutY(90);
        b_help.setLayoutX(285);
        b_help.setTextFill(Color.WHITE);
        b_help.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 14));
        b_help.setPrefSize(30, 30);
        b_help.setShape(new Circle(1.5));


        //POSITION DES BOUTONS
        humainvsHumain.setLayoutY(140);
        humainvsHumain.setLayoutX(25);

        solo.setLayoutX(25);
        solo.setLayoutY(190);

        quitter.setLayoutX(25);
        quitter.setLayoutY(270);

        //TAILLE DES BOUTONS
        solo.setPrefSize(300,30);
        humainvsHumain.setPrefSize(300,30);
        quitter.setPrefSize(300,30);


        solo.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 18));
        solo.setTextFill(Color.WHITE);
        solo.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null)));
        solo.setOnMouseEntered(e->solo.setBackground(new Background(new BackgroundFill(Color.rgb(33,232,46),null, null))));
        solo.setOnMouseExited(e->solo.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null))));

        humainvsHumain.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 18));
        humainvsHumain.setTextFill(Color.WHITE);
        humainvsHumain.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null)));
        humainvsHumain.setOnMouseEntered(e->humainvsHumain.setBackground(new Background(new BackgroundFill(Color.rgb(33,232,46),null, null))));
        humainvsHumain.setOnMouseExited(e->humainvsHumain.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null))));


        quitter.setTextFill(Color.WHITE);
        quitter.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 18));
        quitter.setBackground(new Background(new BackgroundFill(Color.rgb(188,10,10), null, null)));
        quitter.setOnMouseEntered(e->quitter.setBackground(new Background(new BackgroundFill(Color.RED, null, null))));
        quitter.setOnMouseExited(e->quitter.setBackground(new Background(new BackgroundFill(Color.rgb(188,10,10), null, null))));


        b_help.setTextFill(Color.WHITE);
        b_help.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 18));
        b_help.setBackground(new Background(new BackgroundFill(Color.rgb(188,10,10), null, null)));
        b_help.setOnMouseEntered(e->b_help.setBackground(new Background(new BackgroundFill(Color.RED, null, null))));
        b_help.setOnMouseExited(e->b_help.setBackground(new Background(new BackgroundFill(Color.rgb(188,10,10), null, null))));

        //ACTION SI HELP
        b_help.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                //création d'une fenetre solo, d'une nouvelle fenêtre et nouvelle scene avec les dimensions
                Stage nouvelle_fenetre = new Stage();
                Regle menuRegle = new Regle(primaryStage, nouvelle_fenetre);
                Scene nouvelle_scene = new Scene(menuRegle,620,900);

                nouvelle_fenetre.setScene(nouvelle_scene);
                //on montre la nouvelle fenêtre
                nouvelle_fenetre.show();

            }
        });

        //ACTION QUAND CLIQUE SUR HUMAIN VS HUMAIN

        humainvsHumain.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                //création d'une fenetre solo, d'une nouvelle fenêtre et nouvelle scene avec les dimensions
                Stage nouvelle_fenetre = new Stage();
                HumainVsHumain humainVsHumain_fenetre = new HumainVsHumain(primaryStage, nouvelle_fenetre);
                Scene nouvelle_scene = new Scene(humainVsHumain_fenetre,620,380);

                nouvelle_fenetre.setScene(nouvelle_scene);
                //on montre la nouvelle fenêtre
                nouvelle_fenetre.show();

                //FERMETURE DE LA FENETRE ACCUEIL
                primaryStage.close() ;
            }
        });

        //ACTION  QUAND SOLO
        solo.setOnAction(new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
            //création d'une fenetre solo, d'une nouvelle fenêtre et nouvelle scene avec les dimensions
            Stage nouvelle_fenetre = new Stage();
            Solo solo_fenetre = new Solo(primaryStage, nouvelle_fenetre);
            Scene nouvelle_scene = new Scene(solo_fenetre,620,380);

            nouvelle_fenetre.setScene(nouvelle_scene);
            //on montre la nouvelle fenêtre
            nouvelle_fenetre.show();

            //FERMETURE DE LA FENETRE ACCUEIL
            primaryStage.close() ;
        }
    });


        //ACTION : SI ON APPUIE SUR QUITTER
        quitter.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                primaryStage.close();
            }
        });

        ////////BLOQUAGE DE REDUCTION DE LA FENETRE
        primaryStage.setMinWidth(210);
        primaryStage.setMinHeight(330);


        // AJOUT A L'ECRAN
        this.getChildren().add(imageView);
        this.getChildren().add(solo);
        this.getChildren().add(humainvsHumain);
        this.getChildren().add(quitter);
        this.getChildren().add(b_help);

    }

}
