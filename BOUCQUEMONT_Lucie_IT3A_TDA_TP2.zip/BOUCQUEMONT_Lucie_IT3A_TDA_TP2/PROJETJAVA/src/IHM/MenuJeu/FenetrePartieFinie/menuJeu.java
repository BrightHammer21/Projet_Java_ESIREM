package IHM.MenuJeu.FenetrePartieFinie;

import IHM.MenuJeu.Accueil;
import IHM.PlateauJeu;
import Métier.Puissance4;
import Métier.initialisationPartie;
import Métier.initialisationPartieIA;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class menuJeu extends Parent {
    public menuJeu(Stage fenetrePartie, Stage cette_fenetre, Puissance4 p) {

        Button menu=new Button("MENU");
        menu.setPrefSize(420,60);
        menu.setLayoutX(0);
        menu.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 30));
        menu.setTextFill(Color.WHITE);
        menu.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null)));


        Button b_FermerMenu=new Button("RETOUR AU JEU");
        b_FermerMenu.setLayoutX(65);
        b_FermerMenu.setLayoutY(100);
        b_FermerMenu.setTextFill(Color.WHITE);
        b_FermerMenu.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 18));
        b_FermerMenu.setPrefSize(300,40);

        Button b_FermerJeu=new Button("QUITTER LE JEU");
        b_FermerJeu.setLayoutX(65);
        b_FermerJeu.setLayoutY(400);
        b_FermerJeu.setTextFill(Color.WHITE);
        b_FermerJeu.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 18));
        b_FermerJeu.setPrefSize(300,40);


        Button b_retourMenu=new Button("MENU PRINCIPAL");
        b_retourMenu.setLayoutX(65);
        b_retourMenu.setLayoutY(300);
        b_retourMenu.setTextFill(Color.WHITE);
        b_retourMenu.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 18));
        b_retourMenu.setPrefSize(300,40);


        Button b_nouvellePartie = new Button("NOUVELLE PARTIE");
        b_nouvellePartie.setLayoutX(65);
        b_nouvellePartie.setLayoutY(200);
        b_nouvellePartie.setTextFill(Color.WHITE);
        b_nouvellePartie.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null)));
        b_nouvellePartie.setFont(Font.font("Verdana", FontWeight.EXTRA_BOLD, 18));
        b_nouvellePartie.setPrefSize(300,40);


        /////////////////////////////////////////////////////////////////////// HOVER
        b_FermerMenu.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null)));
        b_FermerMenu.setOnMouseEntered(e->b_FermerMenu.setBackground(new Background(new BackgroundFill(Color.rgb(33,232,46), null, null))));
        b_FermerMenu.setOnMouseExited(e->b_FermerMenu.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null))));



        b_nouvellePartie.setBackground(new Background(new BackgroundFill(Color.rgb(188,10,10), null, null)));
        b_nouvellePartie.setOnMouseEntered(e->b_nouvellePartie.setBackground(new Background(new BackgroundFill(Color.RED, null, null))));
        b_nouvellePartie.setOnMouseExited(e->b_nouvellePartie.setBackground(new Background(new BackgroundFill(Color.rgb(188,10,10), null, null))));


        b_FermerJeu.setBackground(new Background(new BackgroundFill(Color.rgb(188,10,10), null, null)));
        b_FermerJeu.setOnMouseEntered(e->b_FermerJeu.setBackground(new Background(new BackgroundFill(Color.RED, null, null))));
        b_FermerJeu.setOnMouseExited(e->b_FermerJeu.setBackground(new Background(new BackgroundFill(Color.rgb(188,10,10), null, null))));

        b_retourMenu.setBackground(new Background(new BackgroundFill(Color.rgb(188,10,10), null, null)));
        b_retourMenu.setOnMouseEntered(e->b_retourMenu.setBackground(new Background(new BackgroundFill(Color.RED, null, null))));
        b_retourMenu.setOnMouseExited(e->b_retourMenu.setBackground(new Background(new BackgroundFill(Color.rgb(188,10,10), null, null))));



        //////////////////////////////////////////////////////////////////////ACTION BOUTON
        b_FermerMenu.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {
                cette_fenetre.close();

            }
        });

        b_FermerJeu.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {
                cette_fenetre.close();
                fenetrePartie.close();
            }
        });

        b_retourMenu.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {


                Group root = new Group();
                Accueil accueil = new Accueil(cette_fenetre);
                cette_fenetre.setScene(new Scene(root, 350, 350));

                root.getChildren().add(accueil);
                cette_fenetre.show();



                fenetrePartie.close();
            }
        });


        b_nouvellePartie.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {

                if(p.getJoueur2().getType()=="IA")
                {
                    //initialisation de la partie
                    initialisationPartieIA partie = new initialisationPartieIA(p.getJoueur1().getNom(),p.getJoueur2().getNom(), p.getJoueur1().getCouleurJeton(), p.getJoueur2().getCouleurJeton());
                    Puissance4 p=new Puissance4(partie.getJoueur1(),partie.getJoueurIA(),partie.getPlateauCase());

                    //création du plateau
                    Stage nouveau_plateau = new Stage();
                    PlateauJeu jeu = new PlateauJeu(cette_fenetre, nouveau_plateau, partie.getJoueur1(),partie.getJoueurIA(), partie.getPlateauCase(), p);
                    Scene scene = new Scene(jeu, 1275, 750);
                    nouveau_plateau.setScene(scene);
                    nouveau_plateau.show();

                    cette_fenetre.close();
                    fenetrePartie.close();

                }
                else
                {
                    //initialisation de la partie
                    initialisationPartie partie = new initialisationPartie(p.getJoueur1().getNom(),p.getJoueur2().getNom(), p.getJoueur1().getCouleurJeton(), p.getJoueur2().getCouleurJeton());
                    Puissance4 p=new Puissance4(partie.getJoueur1(),partie.getJoueur2(),partie.getPlateauCase());

                    //création du plateau
                    Stage nouveau_plateau = new Stage();
                    PlateauJeu jeu = new PlateauJeu(cette_fenetre, nouveau_plateau, partie.getJoueur1(),partie.getJoueur2(), partie.getPlateauCase(), p);
                    Scene scene = new Scene(jeu, 1275, 750);
                    nouveau_plateau.setScene(scene);
                    nouveau_plateau.show();

                    cette_fenetre.close();
                    fenetrePartie.close();
                }

            }
        });

        ///EMPEPCHE LA FENETRE D'ETRE FERMEE

        cette_fenetre.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent event) {
                event.consume();
            }
        });


        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        this.getChildren().add(menu);
        this.getChildren().add(b_FermerMenu);
        this.getChildren().add(b_FermerJeu);
        this.getChildren().add(b_retourMenu);
        this.getChildren().add(b_nouvellePartie);
    }
}
