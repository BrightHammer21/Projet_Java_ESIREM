package Métier;

import Entités.Coordonnées;
import Entités.Humain;
import Entités.IA;
import Entités.Joueur;
import javafx.scene.paint.Color;

public class initialisationPartieIA {

    protected Joueur joueur1;
    protected Joueur joueurIA;
    protected Case[][] plateauCase;
    private int nbLignes=6;
    private int nbColonne=7;
    private Puissance4 p;

    public initialisationPartieIA(String nomJoueur1, String nomJoueur2, Color couleurJ1, Color couleurJ2)
    {
        System.out.println("Partie IA");
        joueur1=new Humain(nomJoueur1,couleurJ1);
        joueurIA=new IA(nomJoueur2,couleurJ2);
        plateauCase = new Case[nbLignes][nbColonne];

        for(int i=0;i<6;i++) {
            for (int j = 0; j < 7; j++) {
                Coordonnées coo = new Coordonnées(i, j);
                plateauCase[i][j] = new Case(coo);

            }
        }
    }

    public Joueur getJoueur1() {
        return joueur1;
    }

    public Joueur getJoueurIA() {
        return joueurIA;
    }

    public Case[][] getPlateauCase() {
        return plateauCase;
    }

    public Puissance4 getP() {
        return p;
    }

}
