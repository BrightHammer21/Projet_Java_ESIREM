package Entités;

import javafx.scene.paint.Color;

public class Humain extends Joueur {

    public Humain(String nom, Color couleur)
    {
        super(nom,couleur);
    }

    @Override
    public String getType() {
        return "humain";
    }
}
