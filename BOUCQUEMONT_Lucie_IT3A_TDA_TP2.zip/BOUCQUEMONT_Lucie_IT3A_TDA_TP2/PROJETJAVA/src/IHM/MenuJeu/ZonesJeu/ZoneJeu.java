package IHM.MenuJeu.ZonesJeu;

import Entités.Coordonnées;
import Entités.Joueur;
import IHM.PlateauJeu;
import Métier.Case;
import Métier.Puissance4;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class ZoneJeu extends Parent {

    private PlateauJeu jeu;
    private Joueur joueur1;
    private Joueur joueur2;
    private Puissance4 p;

    private int compteur=0;
    private int posY=180;
    private int posX=270;

    private Pane zoneJeu;
    private Case[][] plateauCase;


    public ZoneJeu(Stage primaryStage, Stage fenetre_actuelle, PlateauJeu jeu, Joueur joueur1, Joueur joueur2, Case[][] plateauCase, Puissance4 p)
    {
        this.jeu=jeu;
        this.joueur1=joueur1;
        this.joueur2=joueur2;
        this.plateauCase=plateauCase;
        this.p=p;


        //Délimitation de la zone du plateau
        Rectangle rectangle = new Rectangle();
        rectangle.setHeight(630);
        rectangle.setWidth(870);
        rectangle.setX(200);
        rectangle.setY(120);
        rectangle.setFill(Color.rgb(35,35,35));
        rectangle.setStroke(Color.BLACK);
        this.getChildren().add(rectangle);


        genererCase();
    }

    public void genererCase()
    {
        zoneJeu = new Pane();

        //Génération des cases

        for(int i=0;i<6;i++)
        {
            for(int j=0;j<7;j++)
            {

                Circle c = new Circle();
                if(plateauCase[i][j].isEstOccupe()==false)
                {
                    c.setFill(Color.WHITE);
                }
                else
                {
                   c.setFill(plateauCase[i][j].getJ().getCouleurJeton());
                }

                c.setRadius(40);
                c.setStroke(Color.BLACK);
                c.setStrokeWidth(1);

                if(compteur==7)
                {
                    compteur = 0;
                    posY+=100;
                    posX=270;
                }
                c.setLayoutX(posX);
                c.setLayoutY(posY);

                posX+=120;
                compteur++;

                zoneJeu.getChildren().add(c);
            }

        }


        posY=80;
        this.getChildren().add(zoneJeu);
    }

    public void detruireCase()
    {
        this.getChildren().removeAll(zoneJeu);
    }


}
